
import React from "react";
import propTypes from "prop-types";

import heartImage from "./../../../../images/svg/heartIcon.svg";
import wishlistImage from "./../../../../images/checkout-tab.png";
import facebookIcon from "./../../../../images/facebook-icon.png";
import googleIcon from "./../../../../images/google-icon.png";

const GuestLogin = ({
  isChecked,
  login,
  email,
  onEmailPasswordChange,
  closeAllModalPopup,
}) => {
  return (
    <div style={{ display: isChecked ? "block" : "none" }}>
      <div className="wishlist-popup">
        <div className="wishlist-popup-block">
          <div className="wishlist-popup-inner flex-row">
            <div className="wishlist-popup-info">
              <div>
                <img
                  src={wishlistImage}
                  alt="img"
                  className="wishlist-popup-info-image"
                />

                <div className="wishlist-popup-contact">
                  <div className="wishlist-popup-contact-icon">
                    <img
                      src="https://www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/help-phone@single.svg"
                      alt=""
                    />
                  </div>
                  <div className="wishlist-popup-contact-info">
                    <span>Need Help?</span>
                    <strong>1300 668 317</strong>
                    <span>Mon-Fri 9am-5pm AEST</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="wishlist-popup-content">
              <div>
                <div className="modal-close" onClick={closeAllModalPopup}></div>
                <h1 className="modal-title">
                  <img src={heartImage} alt="img" />
                  &nbsp; &nbsp; Wishlist
                </h1>
                <p>Sign in and access your wishlist on any device.</p>
                <form
                  className="wishlist-popup-form"
                  action=""
                  onSubmit={login}
                >
                  <div className="form-group-slide">
                    <input
                      type="email"
                      required
                      value={email}
                      placeholder="Email Address"
                      readOnly
                    />
                    <label>Email Address</label>
                  </div>
                  <div className="form-group-slide">
                    <input
                      type="password"
                      required
                      onChange={onEmailPasswordChange.bind(this, "password")}
                      placeholder="Password"
                    />
                    <label>Password</label>
                  </div>
                  <span>
                    <a>Forgot password?</a>
                  </span>

                  <button className="btn-full">Sign in &amp; Continue</button>
                  <p className="signup-text">or Sign up with</p>
                </form>
                <div className="social-login">
                  <button>
                    <img src={facebookIcon} height="14" />
                    Facebook
                  </button>
                  <button>
                    <img src={googleIcon} height="14" />
                    Google
                  </button>
                </div>
              </div>
            </div>{" "}
          </div>
        </div>
      </div>
    </div>
  );
};

GuestLogin.propTypes = {
  isChecked: propTypes.bool,
};

export default GuestLogin;
