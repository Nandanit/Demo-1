import React from "react";
import propTypes from "prop-types";

import AutoCompleteText from "./../../AutoCompleteText/AutoCompleteText"

import heartImage from "./../../../../images/svg/heartIcon.svg";
import wishlistImage from "./../../../../images/checkout-tab.png";
import facebookIcon from "./../../../../images/facebook-icon.png";
import googleIcon from "./../../../../images/google-icon.png";

class GuestUser extends React.Component {
  render() {
    const {
      email,
      isChecked,
      GuestWishlistLogin,
      userEmailChangeHandler,
      closeAllModalPopup,
    } = this.props;
    return (
      <div
        className="wishlist-popup"
        style={{ display: isChecked ? "block" : "none" }}
      >
        <div className="wishlist-popup-block">
          <div className="wishlist-popup-inner flex-row">
            <div className="wishlist-popup-info">
              <div>
                <img
                  src={wishlistImage}
                  alt="img"
                  className="wishlist-popup-info-image"
                />

                <div className="wishlist-popup-contact">
                  <div className="wishlist-popup-contact-icon">
                    <img
                      src="https://www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/help-phone@single.svg"
                      alt=""
                    />
                  </div>
                  <div className="wishlist-popup-contact-info">
                    <span>Need Help?</span>
                    <strong>1300 668 317</strong>
                    <span>Mon-Fri 9am-5pm AEST</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="wishlist-popup-content">
              <div>
                <div className="modal-close" onClick={closeAllModalPopup}></div>

                <h1 className="modal-title">
                  <img src={heartImage} alt="img" />
                  &nbsp; &nbsp;Wishlist
                </h1>
                <p>
                  Enter your email address to sign in or sign up and access your
                  wishlist in any device.
                </p>

                <form
                  className="wishlist-popup-form AutoCompleteText"
                  onSubmit={GuestWishlistLogin}
                >
                  <div className="form-group-slide">
                    <AutoCompleteText
                      userEmailChangeHandler={userEmailChangeHandler}
                      text={email}
                    />
                    <label>Email Address</label>
                  </div>

                  <button className="btn-full">Continue</button>
                  <p className="signup-text">or Sign up with</p>
                </form>
                <div className="social-login">
                  <button>
                    <img src={facebookIcon} height="16" />
                    Facebook
                  </button>
                  <button>
                    <img src={googleIcon} height="16" />
                    Google
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

GuestUser.propTypes = {
  isChecked: propTypes.bool,
};

export default GuestUser;