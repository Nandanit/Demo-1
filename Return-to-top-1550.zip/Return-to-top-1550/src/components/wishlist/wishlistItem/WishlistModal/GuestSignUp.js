import React from "react";
import propTypes from "prop-types";

import wishlistImage from "./../../../../images/checkout-tab.png";
import facebookIcon from "./../../../../images/facebook-icon.png";
import googleIcon from "./../../../../images/google-icon.png";

const GuestSignUp = ({
  isChecked,
  signup,
  email,
  onEmailPasswordChange,
  closeAllModalPopup,
}) => {
  return (
    <div style={{ display: isChecked ? "block" : "none" }}>
      <div className="wishlist-popup">
        <div className="wishlist-popup-block">
          <div className="wishlist-popup-inner flex-row">
            <div className="wishlist-popup-info">
              <div>
                <img
                  src={wishlistImage}
                  alt="img"
                  className="wishlist-popup-info-image"
                />

                <div className="wishlist-popup-contact">
                  <div className="wishlist-popup-contact-icon">
                    <img
                      src="https://www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/help-phone@single.svg"
                      alt=""
                    />
                  </div>
                  <div className="wishlist-popup-contact-info">
                    <span>Need Help?</span>
                    <strong>1300 668 317</strong>
                    <span>Mon-Fri 9am-5pm AEST</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="wishlist-popup-content">
              <div>
                <div className="modal-close" onClick={closeAllModalPopup}></div>
                <h1 className="modal-title">Save your wishlist</h1>
                <p>
                  Sign up to create a new account and add products into your
                  wishlist.
                </p>
                <form
                  className="wishlist-popup-form"
                  action=""
                  onSubmit={signup}
                >
                  <div className="form-group-slide">
                    <input
                      type="email"
                      required
                      value={email}
                      placeholder="Email Address"
                      readOnly
                    />
                    <label>Email Address</label>
                  </div>

                  <div className="form-c-pass">
                    <div className="form-c-pass-text">
                      Looks like this is your first purchase with Zanui. Would
                      you like to create an account?
                    </div>
                    <div className="form-group-slide">
                      <input
                        type="password"
                        required
                        onChange={onEmailPasswordChange.bind(this, "password")}
                        placeholder="Create Password (optional)"
                      />
                      <label>Create Password (optional)</label>

                      {/* <div className="tooltip">
                         <span className="tooltip-close">&#215;</span>
                        <span>Strength</span>
                        <div className="tooltip-progress">
                          <progress id="file" value="32" max="100">
                            32%
                          </progress>
                          <b>Strong</b>
                        </div>
                        <ul>
                          <li>6-20 Characters</li>
                          <li>
                            Only consist of letters, numbers &amp; Symbols
                          </li>
                          <li>
                            Consists at least two of the following: letters,
                            numbers &amp; Symbols
                          </li>
                        </ul>
                      </div> */}
                    </div>
                  </div>
                  <p className="form-checkBox">
                    <input type="checkbox" id="email-checkBox" />
                    &nbsp;
                    <label htmlFor="email-checkBox">
                      I would like to receive emails about special promos and
                      offers from Zanui.
                    </label>
                  </p>
                  <button className="btn-full">Continue</button>
                  <p className="signup-text">or Sign up with</p>
                </form>
                <div className="social-login">
                  <button>
                    <img src={facebookIcon} height="14" />
                    Facebook
                  </button>
                  <button>
                    <img src={googleIcon} height="14" />
                    Google
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

GuestSignUp.propTypes = {
  isChecked: propTypes.bool,
};


export default GuestSignUp;
