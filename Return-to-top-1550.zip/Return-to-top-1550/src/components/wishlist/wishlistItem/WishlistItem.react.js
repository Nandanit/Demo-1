import React, { Component } from 'react';
import propTypes from "prop-types";

class wishlistItem extends Component {
    constructor(props) {
        super(props);
        this.onWishlistClick = this.onWishlistClick.bind(this);
      }
    
      onWishlistClick = () => {
        if (this.props.isLoggedIn) {
          console.log(this.props);
          this.props.addToWishlist(this.props.productId);
        } else {
          this.props.GuestWishlist();
        }
      };
      render() {
        return (
          <div className="w-clearfix product-listing-item gtm-product-listing-item product-listing-item-block">
            <a
              className="w-inline-block product-image-block"
              href="google.com"
              target="_blank"
              style={{
                height: "363px",
                maxHeight: "363px",
                paddingTop: "0",
              }}
            >
              <img
                alt="img"
                src="//images.zanui.com.au/unsafe/trim/fit-in/400x400/filters:sharpen(1,0.2,1):quality(80):fill(fff,false)/production-static.aws.zanui.com.au/p/simpel-267401-232763.jpg"
                className="image-replace"
                width="400"
              />
              <div className="product-list-badge-wrap">
                <div className="product-attribute-badge">
                  <div className="w-clearfix attributes-block">
                    <div className="attributes-text">Iniko</div>
                    <ul className="w-list-unstyled w-clearfix colour-swatches-list">
                      <li className="w-clearfix colour-swatch-list-item">
                        <div className="colour-swatch-block">
                          <img
                            alt="img"
                            src="{item.productImg}"
                            width="16"
                            height="8"
                          />
                        </div>
                      </li>
                      <li className="w-clearfix colour-swatch-list-item">
                        <div className="colour-swatch-block">
                          <img
                            alt="img"
                            // src={colourSwatchImage[0]}
                            width="16"
                            height="8"
                          />
                        </div>
                      </li>
                      <li className="w-clearfix colour-swatch-list-item">
                        <div className="colour-swatch-block">
                          <img
                            alt="img"
                            // src={colourSwatchImage[1]}
                            width="16"
                            height="8"
                          />
                        </div>
                      </li>
                      <li className="w-clearfix colour-swatch-list-item">
                        <div className="colour-swatch-block">
                          <img
                            alt="img"
                            // src={colourSwatchImage[2]}
                            width="16"
                            height="8"
                          />
                        </div>
                      </li>
                      <li className="w-clearfix colour-swatch-list-item">
                        <div className="colour-swatch-block">
                          <img
                            alt="img"
                            // src={colourSwatchImage[3]}
                            width="16"
                            height="8"
                          />
                        </div>
                      </li>
                      <li className="w-clearfix colour-swatch-list-item">
                        <div className="colour-swatch-block">
                          <img
                            alt="img"
                            // src={colourSwatchImage}
                            width="16"
                            height="8"
                          />
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </a>
    
            <div className="product-listing-item details product-listing">
              <div className="w-row">
                <div className="w-col w-col-10 w-col-small-10 w-col-tiny-10">
                  <a
                    className="first-part product-details-block w-inline-block"
                    href="google.com"
                    target="_blank"
                  >
                    <div className="brand-name small-labels">
                      Bamberg Velvet Dining Chair1
                    </div>
                  </a>
                  <a
                    className="second-part product-details-block w-inline-block"
                    href="google.com"
                    target="_blank"
                  >
                    <div className="product-block-name">
                      Bamberg Velvet Dining Chair
                    </div>
    
                    <div className="product-block-price sale">from $177</div>
    
                    <div className="price-review-block">
                      <div className="product-review-stars">
                        <div className="star-group">
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                        </div>
                        <div className="review-stars-text">(37)</div>
                      </div>
                    </div>
                  </a>
                </div>
                <div className="w-col w-col-2 w-col-small-2 w-col-tiny-2 w-clearfix">
                  <div className="w-inline-block product-wishlist-block react_wishlist-ball">
                    <span className="render-container">
                      <div className="icon " data-behat="add-to-wishlist">
                        <img
                          alt="img"
                          width="30"
                          height="30"
                          className="img-add "
                          src="//www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/add-wishlist@single.svg"
                          onClick={this.onWishlistClick}
                        />
                        <img
                          alt="img"
                          width="30"
                          height="30"
                          className="img-remove hidden"
                          src="//www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/remove-wishlist@single.svg"
                        />
                      </div>
                      <div className="hidden">
                        <div>Save to wishlist</div>
                        <div className="tooltip-indicator product-listing-wishlist"></div>
                      </div>
                    </span>
                  </div>
                </div>
                <div className="w-col w-col-10 w-col-small-10 w-col-tiny-10">
                  <a
                    className="first-part product-details-block w-inline-block"
                    href="google.com"
                    target="_blank"
                  >
                    <div className="brand-name small-labels">
                      Bamberg Velvet Dining Chair
                    </div>
                  </a>
                  <a
                    className="second-part product-details-block w-inline-block"
                    href="google.com"
                    target="_blank"
                  >
                    <div className="product-block-name">
                      Bamberg Velvet Dining Chair
                    </div>
    
                    <div className="product-block-price sale">from $177</div>
    
                    <div className="price-review-block">
                      <div className="product-review-stars">
                        <div className="star-group">
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                        </div>
                        <div className="review-stars-text">(37)</div>
                      </div>
                    </div>
                  </a>
                </div>
                <div className="w-col w-col-2 w-col-small-2 w-col-tiny-2 w-clearfix">
                  <div className="w-inline-block product-wishlist-block react_wishlist-ball">
                    <span className="render-container">
                      <div className="icon " data-behat="add-to-wishlist">
                        <img
                          alt="img"
                          width="30"
                          height="30"
                          className="img-add "
                          src="//www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/add-wishlist@single.svg"
                          onClick={this.onWishlistClick}
                        />
                        <img
                          alt="img"
                          width="30"
                          height="30"
                          className="img-remove hidden"
                          src="//www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/remove-wishlist@single.svg"
                        />
                      </div>
                      <div className="hidden">
                        <div>Save to wishlist</div>
                        <div className="tooltip-indicator product-listing-wishlist"></div>
                      </div>
                    </span>
                  </div>
                </div>
              
                <div className="w-col w-col-10 w-col-small-10 w-col-tiny-10">
                  <a
                    className="first-part product-details-block w-inline-block"
                    href="google.com"
                    target="_blank"
                  >
                    <div className="brand-name small-labels">
                      Bamberg Velvet Dining Chair
                    </div>
                  </a>
                  <a
                    className="second-part product-details-block w-inline-block"
                    href="google.com"
                    target="_blank"
                  >
                    <div className="product-block-name">
                      Bamberg Velvet Dining Chair
                    </div>
    
                    <div className="product-block-price sale">from $177</div>
    
                    <div className="price-review-block">
                      <div className="product-review-stars">
                        <div className="star-group">
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                        </div>
                        <div className="review-stars-text">(37)</div>
                      </div>
                    </div>
                  </a>
                </div>
                <div className="w-col w-col-2 w-col-small-2 w-col-tiny-2 w-clearfix">
                  <div className="w-inline-block product-wishlist-block react_wishlist-ball">
                    <span className="render-container">
                      <div className="icon " data-behat="add-to-wishlist">
                        <img
                          alt="img"
                          width="30"
                          height="30"
                          className="img-add "
                          src="//www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/add-wishlist@single.svg"
                          onClick={this.onWishlistClick}
                        />
                        <img
                          alt="img"
                          width="30"
                          height="30"
                          className="img-remove hidden"
                          src="//www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/remove-wishlist@single.svg"
                        />
                      </div>
                      <div className="hidden">
                        <div>Save to wishlist</div>
                        <div className="tooltip-indicator product-listing-wishlist"></div>
                      </div>
                    </span>
                  </div>
                </div>
              
                <div className="w-col w-col-10 w-col-small-10 w-col-tiny-10">
                  <a
                    className="first-part product-details-block w-inline-block"
                    href="google.com"
                    target="_blank"
                  >
                    <div className="brand-name small-labels">
                      Bamberg Velvet Dining Chair
                    </div>
                  </a>
                  <a
                    className="second-part product-details-block w-inline-block"
                    href="google.com"
                    target="_blank"
                  >
                    <div className="product-block-name">
                      Bamberg Velvet Dining Chair
                    </div>
    
                    <div className="product-block-price sale">from $177</div>
    
                    <div className="price-review-block">
                      <div className="product-review-stars">
                        <div className="star-group">
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                          <span>
                            <span className="z-icon-star  "></span>
                          </span>
                        </div>
                        <div className="review-stars-text">(37)</div>
                      </div>
                    </div>
                  </a>
                </div>
                <div className="w-col w-col-2 w-col-small-2 w-col-tiny-2 w-clearfix">
                  <div className="w-inline-block product-wishlist-block react_wishlist-ball">
                    <span className="render-container">
                      <div className="icon " data-behat="add-to-wishlist">
                        <img
                          alt="img"
                          width="30"
                          height="30"
                          className="img-add "
                          src="//www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/add-wishlist@single.svg"
                          onClick={this.onWishlistClick}
                        />
                        <img
                          alt="img"
                          width="30"
                          height="30"
                          className="img-remove hidden"
                          src="//www.zanui.com.au/wp-content/themes/flamingo-wp-theme/assets/images/remove-wishlist@single.svg"
                        />
                      </div>
                      <div className="hidden">
                        <div>Save to wishlist</div>
                        <div className="tooltip-indicator product-listing-wishlist"></div>
                      </div>
                    </span>
                  </div>
                </div>
              
              
              
              </div>
            </div>
          </div>
        );
      }
    }
    
    wishlistItem.propTypes = {
      price: propTypes.number,
      inWishlist: propTypes.bool,
      addToWishlist: propTypes.func,
      isLoggedIn: propTypes.bool,
    };
 
export default wishlistItem;