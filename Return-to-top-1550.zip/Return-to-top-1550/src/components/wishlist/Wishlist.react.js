import React, { Component } from 'react';
import reqwest from "reqwest";

import WishlistItem from "./wishlistItem/WishlistItem.react";
import GuestUser from "./wishlistItem/WishlistModal/GuestUser";
import GuestLogin from "./wishlistItem/WishlistModal/GuestLogin";
import GuestSignUp from "./wishlistItem/WishlistModal/GuestSignUp";

import "./wishlist.scss"

class Wishlist extends Component {
    constructor() {
        super();
        this.state = {
          // sample products
          products: [
            {
              product_id: 1111,
              price: 1149,
              in_wishlist: false,
            },
            {
              product_id: 1112,
              price: 1000,
              in_wishlist: false,
            },
            {
              product_id: 1111,
              price: 1149,
              in_wishlist: false,
            },
            {
              product_id: 1112,
              price: 1000,
              in_wishlist: false,
            },
            {
              product_id: 1111,
              price: 1149,
              in_wishlist: false,
            },
            {
              product_id: 1112,
              price: 1000,
              in_wishlist: false,
            },
            {
              product_id: 1111,
              price: 1149,
              in_wishlist: false,
            },
            {
              product_id: 1112,
              price: 1000,
              in_wishlist: false,
            },
            {
              product_id: 1111,
              price: 1149,
              in_wishlist: false,
            },
            {
              product_id: 1112,
              price: 1000,
              in_wishlist: false,
            },
          ],
          // sample customer id
          customer_id: 384711,
          // current user wishlist
          customerWishlistProducts: [],
          // user logged in status
          isLoggedIn: false,
          // First popup if guest user
          guestUserWishlistPopup: false,
          // Login popup modal for guest user
          guestUserLoginPopup: false,
          // guest user sign up popup
          guestUserSignupPopup: false,
          // guest user credential
          guestUserDetails: {
            email: "",
            password: "",
          },
        };
        this.addToWishlist = this.addToWishlist.bind(this);
        this.removeFromWishlist = this.removeFromWishlist.bind(this);
        this.GuestWishlist = this.GuestWishlist.bind(this);
        this.GuestWishlistLogin = this.GuestWishlistLogin.bind(this);
        this.login = this.login.bind(this);
      }
      // when component mounts change wishlist value if already in wishlist
      componentDidMount() {
        if (this.state.isLoggedIn) {
          reqwest({
            url: "http://localhost:8000/wishlist/" + this.state.customer_id,
            method: "GET",
          })
            .then((resp) => {
              this.setState({
                customerWishlistProducts: resp.products,
              });
              // this function will change wishlist value if already in wishlist
              Object.values(resp.products).forEach((value) => {
                const findProduct = this.state.products.find(
                  (d) => d.product_id.toString() === value.product_id
                );
                findProduct.in_wishlist = true;
                this.setState({
                  products: this.state.products,
                });
              });
            })
            .fail(() => {
              console.log("error");
            });
        }
      }
    
      userEmailChangeHandler = (event) => {
        this.setState((prevState) => {
          let guestUserDetails = Object.assign({}, prevState.guestUserDetails);
          guestUserDetails.email = event;
          return { guestUserDetails };
        });
      };
    
      onEmailPasswordChange = (fieldName, event) => {
        event.persist();
        this.setState((prevState) => {
          let guestUserDetails = Object.assign({}, prevState.guestUserDetails);
          guestUserDetails.password = event.target.value;
          return { guestUserDetails };
        });
      };
    
      GuestWishlist = () => {
        this.setState({
          guestUserWishlistPopup: true,
        });
      };
    
      GuestWishlistLogin = (event) => {
        event.preventDefault();
    
        var emailFound = false;
        // make a api request fo find if user email exists here
    
        if (emailFound) {
          this.setState({
            guestUserWishlistPopup: false,
            guestUserLoginPopup: true,
            guestUserSignupPopup: false,
          });
        } else {
          this.setState({
            guestUserWishlistPopup: false,
            guestUserSignupPopup: true,
            guestUserLoginPopup: false,
          });
        }
      };
    
      login = (event) => {
        event.preventDefault();
        // code for login goes here
        this.setState({
          guestUserWishlistPopup: false,
          guestUserLoginPopup: false,
        });
      };
    
      // Signup
      signup = (event) => {
        event.preventDefault();
        // Code for signup goes here
        this.setState({
          guestUserWishlistPopup: false,
          guestUserSignupPopup: false,
        });
      };
      // add to wishlist
      addToWishlist = (productId) => {
        let requestData = {
          product_id: productId,
          customer_id: this.state.customer_id,
        };
    
        // call an api for adding an product to wishlist
        reqwest({
          url: "http://localhost:8000/wishlist",
          method: "POST",
          data: requestData,
        }).then((resp) => {
          var findProduct = this.state.products.find(
            (data) => data.product_id === productId
          );
          findProduct.in_wishlist = true;
          this.setState({
            products: this.state.products,
          });
        });
      };
      // remove from wishlist
      removeFromWishlist = (productId) => {
        let requestData = {
          product_id: productId,
          customer_id: this.state.customer_id,
        };
        // call an delete from wishlist api for an product
        reqwest({
          url: "http://localhost:8000/wishlist/delete",
          method: "POST",
          data: requestData,
        }).then((resp) => {
          console.log(resp);
          var findProduct = this.state.products.find(
            (data) => data.product_id === productId
          );
          findProduct.in_wishlist = false;
          this.setState({
            products: this.state.products,
          });
        });
      };
    
      closeAllModalPopup = (event) => {
        event.preventDefault();
        // const { guestUserDetails } = this.state;
    
        this.setState({
          guestUserWishlistPopup: false,
          guestUserSignupPopup: false,
          guestUserLoginPopup: false,
        });
      };
      render() {
        const { guestUserDetails } = this.state;
    
        return (
          <React.Fragment>
            {this.state.products.map((product) => (
              <WishlistItem
                inWishlist={product.in_wishlist}
                key={product.product_id}
                price={product.price}
                addToWishlist={this.addToWishlist}
                removeFromWishlist={this.removeFromWishlist}
                productId={product.product_id}
                isLoggedIn={this.state.isLoggedIn}
                GuestWishlist={this.GuestWishlist}
              />
            ))}
    
            {!this.state.isLoggedIn && (
              <GuestUser
                email={this.state.guestUserDetails.email}
                isChecked={this.state.guestUserWishlistPopup}
                GuestWishlistLogin={this.GuestWishlistLogin}
                userEmailChangeHandler={this.userEmailChangeHandler.bind(this)}
                closeAllModalPopup={this.closeAllModalPopup.bind(this)}
              />
            )}
    
            {!this.state.isLoggedIn && (
              <GuestLogin
                isChecked={this.state.guestUserLoginPopup}
                login={this.login}
                onEmailPasswordChange={this.onEmailPasswordChange.bind(this)}
                email={this.state.guestUserDetails.email}
                closeAllModalPopup={this.closeAllModalPopup.bind(this)}
              />
            )}
    
            {!this.state.isLoggedIn && (
              <GuestSignUp
                isChecked={this.state.guestUserSignupPopup}
                signup={this.signup}
                onEmailPasswordChange={this.onEmailPasswordChange.bind(this)}
                email={this.state.guestUserDetails.email}
                closeAllModalPopup={this.closeAllModalPopup.bind(this)}
              />
            )}
          </React.Fragment>
        );
      }
    }
 
export default Wishlist;