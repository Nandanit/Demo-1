var React = require("react");
require("./AutoCompleteText.css");

var EmailData = require("./email-data.json");

class AutoCompleteText extends React.Component {
  constructor(props) {
    super(props);
    this.items = EmailData.map((value) => value.email);
    this.state = {
      suggestions: [],
      text: "",
      setIndex: -1,
    };
    this.onKeyDown = this.onKeyDown.bind(this);
  }
  onKeyDown = (e) => {
    let ul = document.getElementById("searchUl");
    if (!ul) {
      return false;
    }
    let li = ul.getElementsByTagName("li");
    let newIndex = 0;
    if (e.keyCode === 40) {
      /**if down arrow clicked */

      newIndex = this.state.setIndex + 1;
      if (li[newIndex] === null) {
        return false;
      }
      this.setState(
        {
          setIndex: newIndex,
        },
        () => {
          li[this.state.setIndex].focus();
        }
      );
    } else if (e.keyCode === 38) {
      /**if up arrow clicked */
      newIndex = this.state.setIndex - 1;
      newIndex = newIndex < 0 ? 0 : newIndex;

      if (li[newIndex] === null) {
        return false;
      }
      this.setState(
        {
          setIndex: newIndex,
        },
        () => {
          li[this.state.setIndex].focus();
        }
      );
    } else if (e.keyCode === 13) {
      /** if enter is clicked */
      li[this.state.setIndex].click();
      this.setState({ setIndex: -1 });
    }
  };
  onTextChanged = (e) => {
    const value = e.target.value;
    let suggestions = [];
    if (value.length > 0 && value.includes("@")) {
      var newValue = value.split("@");
      suggestions = this.items.map((item) => newValue[0] + item);
      const regex = new RegExp(`[@]${newValue[1]}`, "i");
      suggestions = suggestions.sort().filter((v) => regex.test(v));
    }
    this.setState(() => ({ suggestions, text: value, setIndex: -1 }));

    this.props.userEmailChangeHandler(value);
  };
  suggestionSelected(value) {
    this.setState(() => ({
      text: value,
      suggestions: [],
    }));
    this.props.userEmailChangeHandler(value);
  }
  renderSuggestions() {
    const { suggestions } = this.state;
    if (suggestions.length === 0) {
      return null;
    }
    var ulStyle = {
      padding: "0",
    };
    var liStyle = {
      listStyleType: "none",
      cursor: "pointer",
      fontColor: "#333",
    };
    return (
      <ul id="searchUl" style={ulStyle}>
        {suggestions.map((item, idx) => (
          <li
            onKeyDown={this.onKeyDown}
            tabIndex={idx}
            ref={this.listRef}
            style={liStyle}
            onClick={() => this.suggestionSelected(item)}
            key={item}
          >
            {item}
          </li>
        ))}
      </ul>
    );
  }
  render() {
    const { text } = this.props;
    return (
      <React.Fragment>
        <input
          value={text}
          onChange={this.onTextChanged}
          type="text"
          onKeyDown={this.onKeyDown}
          placeholder="Email Address"
        />
        {this.renderSuggestions()}
      </React.Fragment>
    );
  }
}

export default AutoCompleteText;
