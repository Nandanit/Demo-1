import React, { Component } from "react";

import homeReturnToTopIcon from "./images/home_top_icon.png";
import homeHelpIcon from "./images/home_help_icon.png";

import "./returnToTop.scss";

class ReturnToTop extends Component {
  constructor() {
    super();
    this.state = {
      showButton: false,
      intervalId: 0,
    };
    this.scrollStepHome = this.scrollStepHome.bind(this);
  }
  componentDidMount() {
    window.addEventListener("scroll", this.showText);
  }
  // Scroll to top button will only be display, when page scrolled
  showText = () => {
    if (window.scrollY > 300) {
      this.setState({
        showButton: true,
      });
    } else {
      this.setState({
        showButton: false,
      });
    }
  };
  scrollStepHome() {
    if (window.pageYOffset === 0) {
      clearInterval(this.state.intervalId);
    }
    window.scroll(0, window.pageYOffset - 50);
  }

  returnToTopHandler() {
    let intervalId = setInterval(this.scrollStepHome, 16);

    this.setState({ intervalId: intervalId });
  }

  render() {
    return (
      <div class="home-help-top">
        {this.state.showButton ? (
          <React.Fragment>
            <a
              title="Back to top"
              className="help-top-buttons"
              onClick={() => {
                this.returnToTopHandler();
              }}
            >
              <img src={homeReturnToTopIcon} alt="top icon" />
              <span>Top</span>
            </a>
            <hr className="help-devider" />
          </React.Fragment>
        ) : null}

        <a
          title="Back to top"
          className="help-top-buttons"
          onClick={() => {
            this.returnToTopHandler();
          }}
        >
          <img src={homeHelpIcon} alt="top icon" />
          <span>Help</span>
        </a>
      </div>
    );
  }
}
export default ReturnToTop;
