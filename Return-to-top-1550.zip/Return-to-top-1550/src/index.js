
import React from "react";
import ReactDOM from "react-dom";

import "./index.scss";
import "font-awesome/css/font-awesome.min.css";
import App from "./App";
import DOM from "./utils/DOM";
// var App = require("./App");

ReactDOM.render(<App />, DOM.select(".root"));
