/*jslint node: true, nomen: true */
/*global document:true, window:true*/

'use strict';

/**
 * Credit: http://youmightnotneedjquery.com/
 */

var _ = require('underscore');

// replace namesLikeThis with names-like-this
function toDashed(name) {
    return name.replace(/([A-Z])/g, function (u) {
        return '-' + u.toLowerCase();
    });
}

var DOM = {
    data: function (node, attr, value) {
        if (arguments.length === 3) {
            return node.setAttribute('data-' + toDashed(attr), value);
        }
        if (arguments.length === 2) {
            return node.getAttribute('data-' + toDashed(attr));
        }
    },

    has: function (parent, child) {
        var node = child;

        while (node) {
            if (node === parent) {
                return true;
            }

            node = node.parentNode;
        }

        return false;
    },

    getWidth: function (ele) {
        return ele.offsetWidth;
    },

    getHeight: function (ele) {
        return ele.offsetHeight;
    },

    setHeight: function (ele, value) {
        ele.style.height = value + (_.isNumber(value) ? 'px' : '');
    },

    windowHeight: function () {
        var w = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0];

        return w.innerHeight || e.clientHeight || g.clientHeight;
    },

    windowWidth: function () {
        var w = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0];

        return w.innerWidth || e.clientWidth || g.clientWidth;
    },

    offset: function (el) {
        var rect = el.getBoundingClientRect();

        return {
            top:  rect.top + document.body.scrollTop,
            left: rect.left + document.body.scrollLeft
        };
    },

    fadeIn: function (el) {
        el.style.opacity = 0;
        this.addClass(el, 'animated fadeIn');
    },

    fadeOut: function (el) {
        el.style.opacity = 1;
        this.addClass(el, 'animated fadeOut');
    },

    hide: function (el) {
        el.style.display = 'none';
    },

    show: function (el, type) {
        type = type || 'block';
        el.style.display = type;
    },

    hasClass: function (el, className) {
        if (el.classList) {
            return el.classList.contains(className);
        }

        return new RegExp('(^| )' + className + '( |$)', 'gi').test(el.className);
    },

    removeClass: function (el, className) {
        if (el.classList) {
            el.classList.remove(className);
        } else {
            el.className = el.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
        }
    },

    addClass: function (el, className) {
        if (el.classList) {
            if (className.indexOf(' ') >= 0) {
                var list = className.split(' ');
                _.each(list, function (element) {
                    el.classList.add(element);
                });
            } else {
                el.classList.add(className);
            }
        } else {
            el.className += ' ' + className;
        }
    },

    toggleClass: function (el, className) {
        if (DOM.hasClass(el, className)) {
            DOM.removeClass(el, className);
        } else {
            DOM.addClass(el, className);
        }
    },

    select: function (selector) {
        return document.querySelector(selector);
    },

    selectAll: function (selector) {
        return document.querySelectorAll(selector);
    },

    find: function (el, selector) {
        return el.querySelector(selector);
    },

    findAll: function (el, selector) {
        return el.querySelectorAll(selector);
    },

    is: function (el, selector) {
        return this._matches(el, selector);
    },

    _matches: function (el, selector) {
        var nodeList = this.findAll((el.parentNode || document), selector) || [],
            i = nodeList.length;

        while (i > 0) {
            i = i - 1;

            if (nodeList[i] === el) {
                return true;
            }
        }

        return false;
    },

    closest: function (el, selector) {
        while (!this._matches(el, selector)) {
            el = el.parentNode || null;

            if (!el) {
                return null;
            }
        }

        return el;
    }
};

module.exports = DOM;
