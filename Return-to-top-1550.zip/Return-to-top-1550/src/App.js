import React, { Component } from "react";
import "./App.scss";
import Wishlist from "./components/wishlist/Wishlist.react";
import ReturnToTop from "./components/ReturnToTop/returnToTop";

class App extends React.Component {
  render() {
    return (
      <React.Fragment>
        <div>
          <Wishlist />
          <ReturnToTop />
        </div>
      </React.Fragment>
    );
  }
}

export default App;
